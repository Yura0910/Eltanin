var app = angular.module('myApp1', []);
app.controller('myCtrl1', function($scope, $http) {
 var myID = 0;  //um die linie zu bearbeiten
 var myID2 = 0; //Um eine zeile zu löschen.
 var var1 = this;
 var1.DataND = [];
 var element = document.getElementById('pb');
 
 //Wir fügen die daten zur tabelle hinzu.
 $scope.addData = function() {
  var1.DataND.push({myText1:var1.data1, myText2:var1.data2, myText3:var1.data3, 
	                myText4:var1.data4});
  var1.data1 = "";
  var1.data2 = "";
  var1.data3 = "";
  var1.data4 = "";
  element.scrollTop = element.scrollHeight - element.clientHeight+500;
 }	
	 
 //Wir bearbeiten die zeile: Wir fügen die daten aus der tabelle in
 //komponenten mit der ID ein: input1, input2 ...
 $scope.editData1 = function (i) {
  $("#myEditData").modal();
  $("#input1").val(document.getElementById("id_a"+i).innerHTML);
  $("#input2").val(document.getElementById("id_b"+i).innerHTML);
  $("#input3").val(document.getElementById("id_c"+i).innerHTML);
  $("#input4").val(document.getElementById("id_d"+i).innerHTML);
  myID = i;
 }
		   
 //Wir speichern die daten aus dem modalen fenster in die tabelle.
 $('#save').click(function() {
  document.getElementById("id_a"+myID).innerHTML = $("#input1").val();
  document.getElementById("id_b"+myID).innerHTML = $("#input2").val();
  document.getElementById("id_c"+myID).innerHTML = $("#input3").val();
  document.getElementById("id_d"+myID).innerHTML = $("#input4").val();
  $('#myEditData').modal('hide');
 });
		   
 //Löschen Sie den stich (die schaltfläche in der tabelle)
 $scope.deleteData1 = function (j) {
  myID2 = j;
  $("#myDeleteData").modal();
 }
		   
 //Klicken sie auf "Löschen"
 $('#delete').click(function() {  
  var element = document.getElementById("id_tr"+myID2);
  while (element.firstChild) {
   element.removeChild(element.firstChild);
  }
  //document.getElementById('myTable').deleteRow(myID2+1);
  /* var element1 = document.getElementById("id_tr"+myID2);
  element1.parentNode.removeChild(element1); */
  $('#myDeleteData').modal('hide'); 
 });
		   
 //Für automatisch kompakt.
 $scope.$watch('$viewContentLoaded', function() {
  //var limit = 10; //Anzahl der zeilen in der dropdown-liste mit suchergebnissen
  var mySource = [
   "Test1",
   "Test2",
   "Test3",
   "Test4",
   "aTest5",
   "aTest6",
   "aTest7",
   "abcd Test8",
   "abcd Test9",
   "abcd Test10"];
  $( "#inputID" ).autocomplete({	    	
   //Begrenzung der menge
   /*source: function(request, response) {
      var results = $.ui.autocomplete.filter(mySource, request.term);
      response(results.slice(0, limit));
   }*/
   maxShowItems: 6, // Make list height fit to 5 items when items are over 5.
   source: mySource
   //Suche nur vom anfang der zeile.
   /*source: function( request, response ) {
      var matcher = new RegExp( "^" + $.ui.autocomplete.escapeRegex( request.term ), "i" );
      response( $.grep( availableTags, function( item ){
       return matcher.test( item );
     }) );
     } */
    });
  });
		   
  //Wir zeigen das modale fenster
  $scope.createDocument = function() {
   $("#mySendData").modal("show");
   $("#myHeader1").html('Das dokument wird erstellt. Bitte warten Sie...');
   $("#myResponse").html('<img src="img/ajax.gif">');
  } 
		   
  //Sobald das modale fenster erschien,
  //Wir senden die daten zur erstellung des dokuments an den server.
  $("#mySendData").on('shown.bs.modal', function () {
   var myJSON = myFunction();
   $.ajax({
    type: 'POST',
    //url: 'http://localhost:8081/eltanin/processData',
    url: 'http://localhost:8080/prj3/processData',
    contentType: 'application/json',
    cache : false,
    async: true,
    data: myJSON,
    success: function(data){
     $("#myHeader1").html('Link herunterladen (siehe unten)');
     $("#myResponse").html(data);
    },
    error: function(jqXHR, textStatus, errorThrown ){
     $("#myHeader1").html('Beim senden einer anfrage ist ein fehler aufgetreten');
     $("#myResponse").html(jqXHR.status + '<br>'+
    		               jqXHR.responseText+ '<br>'+
    		               textStatus+ '<br>'+
    		               errorThrown);
	}
   }); 
 });
   
 //Wir wählen alle daten aus der tabelle aus.
 function myFunction() {
  var oTable = document.getElementById('myTable');
  var rowLength = oTable.rows.length;
  var cellVal = '{ "myDataJSON" : [';
  var tmpArray = [];
  var arrIndex = 0;
  for (i = 1; i < rowLength; i++){
   var oCells = oTable.rows.item(i).cells;
   if (oCells.length > 0){
	   tmpArray[arrIndex] = '{"Header": "'+oCells.item(0).innerHTML+'",'+
                             '"Data": "'  +oCells.item(1).innerHTML+'",'+
                             '"Number": "'+oCells.item(2).innerHTML+'",'+
                             '"Note": "'  +oCells.item(3).innerHTML+'"}';
	   arrIndex++;
   }
  }
  for (j = 0; j < tmpArray.length; j++){
   if (j < tmpArray.length-1){
    cellVal = cellVal + tmpArray[j] +','; 
   }
   if (j == tmpArray.length-1){
    cellVal = cellVal + tmpArray[j] 
   } 
  }
  cellVal = cellVal + ']}';
  return cellVal;
 }
});
 