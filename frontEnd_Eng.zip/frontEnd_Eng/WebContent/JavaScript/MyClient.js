var app = angular.module('myApp1', []);
app.controller('myCtrl1', function($scope, $http) {
 var myID = 0;  //to edit the line
 var myID2 = 0; //To delete a row.
 var var1 = this;
 var1.DataND = [];
 var element = document.getElementById('pb');
 
 //We add the data to the table.
 $scope.addData = function() {
  var1.DataND.push({myText1:var1.data1, myText2:var1.data2, myText3:var1.data3, 
	                myText4:var1.data4});
  var1.data1 = "";
  var1.data2 = "";
  var1.data3 = "";
  var1.data4 = "";
  element.scrollTop = element.scrollHeight - element.clientHeight+500;
 }	
	 
 //We edit the line: we put the data from the table into components 
 //with id: input1, input2 ...
 $scope.editData1 = function (i) {
  $("#myEditData").modal();
  $("#input1").val(document.getElementById("id_a"+i).innerHTML);
  $("#input2").val(document.getElementById("id_b"+i).innerHTML);
  $("#input3").val(document.getElementById("id_c"+i).innerHTML);
  $("#input4").val(document.getElementById("id_d"+i).innerHTML);
  myID = i;
 }
		   
 //We save the data from the modal window into the table.
 $('#save').click(function() {
  document.getElementById("id_a"+myID).innerHTML = $("#input1").val();
  document.getElementById("id_b"+myID).innerHTML = $("#input2").val();
  document.getElementById("id_c"+myID).innerHTML = $("#input3").val();
  document.getElementById("id_d"+myID).innerHTML = $("#input4").val();
  $('#myEditData').modal('hide');
 });
		   
 //Delete row (button in the table)
 $scope.deleteData1 = function (j) {
  myID2 = j;
  $("#myDeleteData").modal();
 }
		   
 //Click on the "Delete" button
 $('#delete').click(function() {  
  var element = document.getElementById("id_tr"+myID2);
  while (element.firstChild) {
   element.removeChild(element.firstChild);
  }
  //document.getElementById('myTable').deleteRow(myID2+1);
  /* var element1 = document.getElementById("id_tr"+myID2);
  element1.parentNode.removeChild(element1); */
  $('#myDeleteData').modal('hide'); 
 });
		   
 //For auto-compact.
 $scope.$watch('$viewContentLoaded', function() {
  //var limit = 10; //Number of rows in the drop-down box with the results. search engine
  var mySource = [
   "Test1",
   "Test2",
   "Test3",
   "Test4",
   "aTest5",
   "aTest6",
   "aTest7",
   "abcd Test8",
   "abcd Test9",
   "abcd Test10"];
  $( "#inputID" ).autocomplete({	    	
   // Limitation of quantity
   /*source: function(request, response) {
      var results = $.ui.autocomplete.filter(mySource, request.term);
      response(results.slice(0, limit));
   }*/
   maxShowItems: 6, // Make list height fit to 5 items when items are over 5.
   source: mySource
   //Search only from the beginning of the line.
   /*source: function( request, response ) {
      var matcher = new RegExp( "^" + $.ui.autocomplete.escapeRegex( request.term ), "i" );
      response( $.grep( availableTags, function( item ){
       return matcher.test( item );
     }) );
     } */
    });
  });
		   
  //We show the modal window
  $scope.createDocument = function() {
   $("#mySendData").modal("show");
   $("#myHeader1").html('The document is being created. Please wait...');
   $("#myResponse").html('<img src="img/ajax.gif">');
  } 
		   
  //As soon as the modal window appeared,
  //We send the data to the server for the formation of the document.
  $("#mySendData").on('shown.bs.modal', function () {
   var myJSON = myFunction();
   $.ajax({
    type: 'POST',
    //url: 'http://localhost:8081/eltanin/processData',
    url: 'http://localhost:8080/prj3/processData',
    contentType: 'application/json',
    cache : false,
    async: true,
    data: myJSON,
    success: function(data){
     $("#myHeader1").html('Download link (see below)');
     $("#myResponse").html(data);
    },
    error: function(jqXHR, textStatus, errorThrown ){
     $("#myHeader1").html('When sending a request, an error occurred');
     $("#myResponse").html(jqXHR.status + '<br>'+
    		               jqXHR.responseText+ '<br>'+
    		               textStatus+ '<br>'+
    		               errorThrown);
	}
   }); 
 });
   
 //We select all the data from the table.
 function myFunction() {
  var oTable = document.getElementById('myTable');
  var rowLength = oTable.rows.length;
  var cellVal = '{ "myDataJSON" : [';
  var tmpArray = [];
  var arrIndex = 0;
  for (i = 1; i < rowLength; i++){
   var oCells = oTable.rows.item(i).cells;
   if (oCells.length > 0){
	   tmpArray[arrIndex] = '{"Header": "'+oCells.item(0).innerHTML+'",'+
                             '"Data": "'  +oCells.item(1).innerHTML+'",'+
                             '"Number": "'+oCells.item(2).innerHTML+'",'+
                             '"Note": "'  +oCells.item(3).innerHTML+'"}';
	   arrIndex++;
   }
  }
  for (j = 0; j < tmpArray.length; j++){
   if (j < tmpArray.length-1){
    cellVal = cellVal + tmpArray[j] +','; 
   }
   if (j == tmpArray.length-1){
    cellVal = cellVal + tmpArray[j] 
   } 
  }
  cellVal = cellVal + ']}';
  return cellVal;
 }
});
 