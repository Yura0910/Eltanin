package com.sauria.eltanin;

import javax.servlet.http.HttpServletRequest;

public class MyURL {
 private HttpServletRequest request;
 MyURL (HttpServletRequest request){
  this.request = request; 
 }
 
 //Create URL for pdf document.
 public String createURL () {
  String protocol = "";  //http  
  int port ;             //8080
  String strPort = "";
  String host = "";      //localhost
  String project = "";
  String myURL = "";
  protocol = request.getScheme();
  port = request.getServerPort();
  host = request.getServerName();
  project = request.getContextPath();
  if (port >= 0) {
   strPort = ":" + String.valueOf(port);
  }
  myURL = protocol + "://"+ host + strPort + project + "/";
  return myURL;
 }
}
