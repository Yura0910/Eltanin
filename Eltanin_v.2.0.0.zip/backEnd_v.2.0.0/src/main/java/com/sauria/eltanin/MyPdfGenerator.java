package com.sauria.eltanin;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Font.FontFamily;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

public class MyPdfGenerator {
 private String[] tmpArr;
 private String physicPath;
 
 MyPdfGenerator(String[] tmpArr, String physicPath){
  this.tmpArr = tmpArr;
  this.physicPath = physicPath;
 }
 
 //Generate the name of the pdf document.
 public String fileName() {
  SimpleDateFormat SimpDF = new SimpleDateFormat("dd-MM-yyyy_HH-mm-ss");
  String str = SimpDF.format(Calendar.getInstance().getTime());
  return "pdf_"+str+".pdf";
 }
 
 //Create pdf document.
 public String myPdfGenerator() throws FileNotFoundException, DocumentException {
  //String path = "src/main/resources/" + fileName();
  String strFileName = fileName();
  String path = physicPath + strFileName;	
  String[] tableHead = new String[]{"Document's name", "Date of the document",
		                            "Sheet numbers", "Note"};
  String[] tmpLineArr = new String[4];
  Document document = new Document();  
  PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(path));
  document.open();
  PdfPTable table = new PdfPTable(4);
  table.setWidthPercentage(100);
  table.setWidths(new float[] {2, (float)0.6, (float)0.7, 2});
  table.setHorizontalAlignment(Element.ALIGN_CENTER);
  Font fontHead = new Font(FontFamily.TIMES_ROMAN, 10);
  for (int i = 0; i < tableHead.length; i++) {
   PdfPCell cellHead = new PdfPCell(new Paragraph(tableHead[i], fontHead));
   cellHead.setVerticalAlignment(Element.ALIGN_MIDDLE);
   cellHead.setHorizontalAlignment(Element.ALIGN_CENTER);
   cellHead.setBackgroundColor(BaseColor.LIGHT_GRAY);
   table.addCell(cellHead);
  }
  Font fontLine = new Font(FontFamily.TIMES_ROMAN, 9);
  for (int j = 0; j <tmpArr.length; j++) {
   tmpLineArr = tmpArr[j].split("\\|");
   for (int a = 0; a < tmpLineArr.length; a++) {
    Paragraph paragraph1 = new Paragraph(tmpLineArr[a],fontLine);
    PdfPCell cellLine = new PdfPCell(paragraph1);
    cellLine.setVerticalAlignment(Element.ALIGN_MIDDLE);
    cellLine.setHorizontalAlignment(Element.ALIGN_CENTER); 
	table.addCell(cellLine);    
   }
  }
  document.add(table);
  document.close();
  writer.close();     
  return strFileName;
 }
}
