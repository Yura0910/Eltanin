package com.sauria.eltanin;

import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.context.annotation.Bean;

@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {
 
 //Password: 12345
 private static final String ENCODED_PASSWORD 
         = "$2a$04$VYIW3uYkRYULl44G1aBz8..pS/nIoQZBGMs7pEYDNsgt.dQ43nBF2";

 @Override
 protected void configure(HttpSecurity http) throws Exception {  
  String[] staticRsr = {"/jquery/**",
		                "/javascript/**",
		                "/bootstrap-4.2.1/css/**",
		                "/bootstrap-4.2.1/js/**",
		                "/css/**",
		                "/popper/**"};
  http
      .csrf().disable()
      .authorizeRequests()
      .antMatchers(staticRsr).permitAll()
      .anyRequest()
      .authenticated()
      .and()
      .formLogin()
      .loginPage("/login")
      .defaultSuccessUrl("/")
      //.failureUrl("/hello.html") //"/hello.html?error=true"
      .permitAll()
      .and()
      .logout()
      .permitAll();
 }
    
 @Bean
 public PasswordEncoder passwordEncoder() {
  return new BCryptPasswordEncoder();
 }
    
 @Override
 protected void configure(AuthenticationManagerBuilder auth) throws Exception {
  auth
      .inMemoryAuthentication()
	  .passwordEncoder(passwordEncoder())
	  .withUser("user")
	  .password(ENCODED_PASSWORD)
	  .roles("USER");
 }
}
