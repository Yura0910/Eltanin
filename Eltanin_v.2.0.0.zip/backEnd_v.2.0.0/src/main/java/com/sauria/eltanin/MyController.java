package com.sauria.eltanin;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.TimeUnit;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import com.itextpdf.text.DocumentException;

@Controller
public class MyController {
 //http://localhost:8081/eltanin/processData
 @PostMapping(value = "/processData",consumes = "application/json")
 public void getRequest(HttpServletRequest request, HttpServletResponse response) 
		                throws IOException, DocumentException, InterruptedException {
  String strReadLine = "";
  String fileName = "";
  String physicPath = "";
  String strURL ="";
  String strFileURL = "";
  
  //retrieving data from a query
  StringBuilder strBilder = new StringBuilder();
  BufferedReader bfrReader = new BufferedReader(new InputStreamReader(request.getInputStream()));
  while ((strReadLine = bfrReader.readLine()) != null) {
   strBilder.append(strReadLine);
  }
  JSONObject jsonObj1 = new JSONObject(strBilder.toString());
  JSONArray jsonArr = jsonObj1.getJSONArray("myDataJSON");
  String[] anArray = new String[jsonArr.length()];
  for (int i = 0; i < jsonArr.length(); i++) {
   JSONObject jsonObj2 = jsonArr.getJSONObject(i);
   for (int j = 0; j < jsonObj2.length(); j++) {
    anArray[i] = jsonObj2.getString("Header")+" |"+
		         jsonObj2.getString("Data")+" |"+
		         jsonObj2.getString("Number")+" |"+
		         jsonObj2.getString("Note")+" |"; 
   }
  }
  bfrReader.close();
  
 //Creation of pdf document
 physicPath  = request.getSession().getServletContext().getRealPath("/");
 //physicPath = physicPath + "resources/";
 MyPdfGenerator pdf = new MyPdfGenerator(anArray,physicPath);
 fileName = pdf.myPdfGenerator();
 
 //Create URL for pdf document.
 MyURL myURL = new MyURL(request);
 strURL = myURL.createURL();
 strFileURL = physicPath + fileName;
 strFileURL = strFileURL.replaceAll("\\\\", "/");
 Path pathFile = Paths.get(strFileURL);
 do {
  TimeUnit.SECONDS.sleep(1);
 }
 while (!Files.exists(pathFile));
 
 //generation of response
 response.setContentType("text/html;charset=UTF-8"); 
 PrintWriter pWriter = response.getWriter();
 pWriter.println("Download: ");
 pWriter.println("<a id=myLink href=\""+strURL+/*"resources/"+*/fileName+"\"  download>pdf</a>"
		   + "<script> $(\"#myLink\").click( function() {$(\"#mySendData\").modal(\"hide\");} );</script> ");
 }
}
