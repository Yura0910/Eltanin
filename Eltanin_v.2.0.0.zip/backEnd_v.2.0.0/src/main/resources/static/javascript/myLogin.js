$(document).ready(function(){
  $('[data-toggle="tooltip"]').tooltip(); 
  $('[data-toggle="tooltip"]').click(function () {
  $('[data-toggle="tooltip"]').tooltip("hide");
    });
 });
$(document).on('show.bs.tooltip', function (e) {
  setTimeout(function() {  
   $('[data-toggle="tooltip"]').tooltip('hide');
  }, 3500);
});